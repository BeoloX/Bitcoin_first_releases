This is a pre-release sourcecode preview.

These are just the main files. The rest is coming soon.

main.h and main.cpp are the bitcoin system
node.h and node.cpp are the peer network communications infrastructure


Legal
-----
This product includes software developed by the OpenSSL Project for use in
the OpenSSL Toolkit (http://www.openssl.org/). This product includes
cryptographic software written by Eric Young (eay@cryptsoft.com).
